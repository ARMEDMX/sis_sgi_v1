<div class="mb-3 row">
    <label for="<?php echo e($nombre); ?>" class="col-4 col-form-label"><?php echo e($nombre); ?>:</label>
    <div class="col-8">
        <select class="form-select " name="<?php echo e($campo); ?>" id="<?php echo e($campo); ?>">
            <option value="ENE/JUN" <?php echo e(old($campo, $valorcampo) == 'ENE/JUN' ? 'selected' : ''); ?>>ENE/JUN</option>
            <option value="AGO/DIC" <?php echo e(old($campo, $valorcampo) == 'AGO/DIC' ? 'selected' : ''); ?>>AGO/DIC</option>
            <!-- Agrega más opciones aquí -->
        </select>
        
        <div class="error">
            <?php $__errorArgs = [$campo];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: brown;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>
<?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/components/select_periodo.blade.php ENDPATH**/ ?>