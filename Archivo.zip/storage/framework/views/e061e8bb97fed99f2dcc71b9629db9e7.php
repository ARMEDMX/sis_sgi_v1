<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/index.css?1.0')); ?>" media="all" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido1'); ?>
    <h1 class="display-3">CATALOGO DEL PERSONAL: </h1>
    <hr>

    <div class="tools">
        <div class="button_new">
            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('personal.create')); ?>" role="button">Nuevo
                Departamento</a>
        </div>

        <div class="search">
            <form action=" <?php echo e(route('deptos.index')); ?> " method="get">
                <input type="text" id="txtnombrecorto" name="txtnombrecorto">
                <input type="submit" value="Buscar">
            </form>
        </div>
        
    </div>

    <hr>

    <div class="table-responsive">
        <?php if($personals->isEmpty()): ?>
            <p>No se encontraron datos existentes.</p>
        <?php else: ?>
            <table id="table"
                class="table table-striped
            table-hover	
            table-borderless
            table-primary
            align-middle">
                <thead class="table-light">
                    <caption>Listado de Personal</caption>
                    <tr>
                        <th>ID</th>
                        <th>RFC</th>
                        <th>Nombres</th>
                        <th>apellidoP</th>
                        <th>apellidoM</th>
                        <th>licenciatura</th>
                        <th>licPasTit</th>
                        <th>especializacion</th>
                        <th>espPasTit</th>
                        <th>maestria</th>
                        <th>maePasTit</th>
                        <th>doctorado</th>
                        <th>docPasTit</th>
                        <th>DEPARTAMENTO</th>
                        <th>fechaIngSep</th>
                        <th>fechaIngIns</th>
                        <th>PUESTO</th>
                        <th>Accion</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            <td><?php echo e($personal->id); ?></td>
                            <td><?php echo e($personal->RFC); ?></td>
                            <td><?php echo e($personal->Nombres); ?></td>
                            <td><?php echo e($personal->apellidoP); ?></td>
                            <td><?php echo e($personal->apellidoM); ?></td>
                            <td><?php echo e($personal->licenciatura); ?></td>
                            <td><?php echo e($personal->licPasTit); ?></td>
                            <td><?php echo e($personal->especializacion); ?></td>
                            <td><?php echo e($personal->espPasTit); ?></td>
                            <td><?php echo e($personal->maestria); ?></td>
                            <td><?php echo e($personal->maePasTit); ?></td>
                            <td><?php echo e($personal->doctorado); ?></td>
                            <td><?php echo e($personal->docPasTit); ?></td>
                            <td><?php echo e($personal->deptos->nombre); ?></td>
                            <td><?php echo e($personal->fechaIngSep); ?></td>
                            <td><?php echo e($personal->fechaIngIns); ?></td>
                            <td><?php echo e($personal->puestos->nombre); ?></td>
                            
                            
                            <td class="accion-btn">

                                
                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('personal.show', ['personal' => $personal->id])); ?>">Ver</a>
                                

                                
                                    <form method="POST" action="<?php echo e(route('personal.destroy', ['personal' => $personal->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input class="btn btn-danger " type="submit" value="Eliminar">
                                    </form>
                                    
                                

                                
                                    <a name="" id="" class="btn btn-secondary" role="button"
                                        href="<?php echo e(route('personal.edit', ['personal' => $personal->id])); ?>">Editar</a>
                                

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <!-- Hoy -->
                </tfoot>
            </table>
    </div>

    <div class="row justify-content-lg-start">
        <div class="col-auto">
            <?php echo e($personals->links()); ?>

        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/personals/index.blade.php ENDPATH**/ ?>