<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/index.css?1.0')); ?>" media="all" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido1'); ?>
    <h1 class="display-3">CATALOGO DE CARRERAS: </h1>
    <hr>

    <div class="tools">
        <div class="button_new">
            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('carreras.create')); ?>" role="button">
                Nueva Carrera
            </a>
                
        </div>

        <div class="search">
            <form action=" <?php echo e(route('carreras.index')); ?> " method="get">
                <input type="text" id="txt" name="txtnombrecorto">
                <input type="submit" value="Buscar">
            </form>
        </div>
    </div>

    <hr>

    <div class="table-responsive">

        <h6 class="display-6"><?php echo e(Session('mensaje')); ?></h6>
        
        <?php if($carreras->isEmpty()): ?>
            <p>No se encontraron datos existentes.</p>
        <?php else: ?>
            <table id="table"
                class="table table-striped
            table-hover	
            table-borderless
            table-primary
            align-middle">
                <thead class="table-light">
                    <caption>Listado de Carreras</caption>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Nombre Corto</th>
                        <th>Departamentos</th>
                        <th>Accion</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($carrera->nombre); ?></td>
                            <td><?php echo e($carrera->nombrecorto); ?></td>
                            <td><?php echo e($carrera->depto->nombre); ?></td>
                            
                            <td class="accion-btn">

                                
                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('carreras.show', ['carrera' => $carrera->id])); ?>">Ver</a>
                                

                                <form method="POST" action="<?php echo e(route('carreras.destroy', ['carrera' => $carrera->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input class="btn btn-danger " type="submit" value="Eliminar">
                                </form>

                                
                                    <a name="" id="" class="btn btn-secondary" role="button"
                                        href="<?php echo e(route('carreras.edit', ['carrera' => $carrera->id])); ?>">
                                        Editar</a>
                                

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <!-- Hoy -->
                </tfoot>
            </table>
    </div>

    <div class="row justify-content-lg-start">
        <div class="col-auto">
            <?php echo e($carreras->links()); ?>

        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/carreras/index.blade.php ENDPATH**/ ?>