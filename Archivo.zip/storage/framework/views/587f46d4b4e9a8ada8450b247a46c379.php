<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DEL LUGAR: </h1>
<hr>
<ul>
    <li><?php echo e($materia->id); ?></li>
    <li><?php echo e($materia->nombreMateria); ?></li>
    <li><?php echo e($materia->nivel); ?></li>
    <li><?php echo e($materia->nombreMediano); ?></li>
    <li><?php echo e($materia->nombreCorto); ?></li>
    <li><?php echo e($materia->modalidad); ?></li>
    <li><?php echo e($materia->reticulas->descripcion); ?></li>
    <li><?php echo e($materia->created_at); ?></li>
    <li><?php echo e($materia->updated_at); ?></li>
</ul>
<hr>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/materias/show.blade.php ENDPATH**/ ?>