<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DEL LUGAR: </h1>
<hr>
<ul>
    <li><?php echo e($Lugares->id); ?></li>
    <li><?php echo e($Lugares->nombreLugar); ?></li>
    <li><?php echo e($Lugares->descripcion); ?></li>
    <li><?php echo e($Lugares->edificio); ?></li>
    <li><?php echo e($Lugares->created_at); ?></li>
    <li><?php echo e($Lugares->updated_at); ?></li>
</ul>
<hr>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/lugares/show.blade.php ENDPATH**/ ?>