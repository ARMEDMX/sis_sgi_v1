<div class="mb-3" row>
    <div class="offset-sm-4 col-sm-8">
        <button type="submit" class="btn btn-primary">Insertar</button>
    </div>
</div><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/components/submit1.blade.php ENDPATH**/ ?>