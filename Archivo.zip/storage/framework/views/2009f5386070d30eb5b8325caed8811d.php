<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/index.css?1.0')); ?>" media="all" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido1'); ?>
    <h1 class="display-3">CATALOGO DE MATERIAS: </h1>
    <hr>

    <div class="tools">
        <div class="button_new">
            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('materias.create')); ?>" role="button">
                Nueva Materia
            </a>
                
        </div>

        <div class="search">
            <form action=" <?php echo e(route('materias.index')); ?> " method="get">
                <input type="text" id="txt" name="txtnombreMateria">
                <input type="submit" value="Buscar">
            </form>
        </div>
    </div>

    <hr>

    <div class="table-responsive">

        <h6 class="display-6"><?php echo e(Session('mensaje')); ?></h6>

        <?php if($materias->isEmpty()): ?>
            <p>No se encontraron datos existentes.</p>
        <?php else: ?>
            <table id="table"
                class="table table-striped
            table-hover	
            table-borderless
            table-primary
            align-middle">
                <thead class="table-light">
                    <caption>Listado de Materias</caption>
                    <tr>
                        <th>ID</th>
                        <th>Nombre de Materia</th>
                        <th>Nivel</th>
                        <th>Nombre Mediano</th>
                        <th>Nombre Corto</th>
                        <th>Modalidad</th>
                        <th>Reticulas</th>
                        <th>Accion</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            
                            <td><?php echo e($materia->id); ?></td>
                            <td><?php echo e($materia->nombreMateria); ?></td>
                            <td><?php echo e($materia->nivel); ?></td>
                            <td><?php echo e($materia->nombreMediano); ?></td>
                            <td><?php echo e($materia->nombreCorto); ?></td>
                            <td><?php echo e($materia->modalidad); ?></td>
                            <td><?php echo e($materia->reticulas->descripcion); ?></td>
                            <td class="accion-btn">

                                
                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('materias.show', ['materia' => $materia->id])); ?>">Ver</a>
                                

                                <form method="POST" action="<?php echo e(route('materias.destroy', ['materia' => $materia->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input class="btn btn-danger " type="submit" value="Eliminar">
                                </form>

                                
                                    <a name="" id="" class="btn btn-secondary" role="button"
                                        href="<?php echo e(route('materias.edit', ['materia' => $materia->id])); ?>">
                                        Editar</a>
                                

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <!-- Hoy -->
                </tfoot>
            </table>
    </div>

    <div class="row justify-content-lg-start">
        <div class="col-auto">
            <?php echo e($materias->links()); ?>

        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/materias/index.blade.php ENDPATH**/ ?>