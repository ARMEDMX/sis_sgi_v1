<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DE LOS DEPARTAMENTOS: </h1>
<hr>
<ul>
    <li><?php echo e($deptos->id); ?></li>
    <li><?php echo e($deptos->nombre); ?></li>
    <li><?php echo e($deptos->nombrecorto); ?></li>
    <li><?php echo e($deptos->descripcion); ?></li>
    <li><?php echo e($deptos->created_at); ?></li>
    <li><?php echo e($deptos->updated_at); ?></li>
</ul>
<hr>
<a name="" id="" class="btn btn-danger" href="<?php echo e(route('deptos.destroy', ['deptos'=>$deptos->id])); ?>" role="button">Eliminar Alumno</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/deptos/show.blade.php ENDPATH**/ ?>