<div class="mb-3 row">
        <label for="<?php echo e($leyenda); ?>" class="col-4 col-form-label"><?php echo e($nombrelbl); ?></label>
    <div class="col-8">
        <select class="form-select" name="<?php echo e($leyenda); ?>"  id="<?php echo e($leyenda); ?>">
        <option selected>Seleccionar</option>
                
                <?php $__currentLoopData = $arreglos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arreglo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($arreglo->$pk); ?>" <?php echo e($arreglo->$pk == $fk ? 'selected' : ''); ?>>
                    <?php echo e($arreglo->$display); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    
    </div>
</div>

    

     <?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/components/select1.blade.php ENDPATH**/ ?>