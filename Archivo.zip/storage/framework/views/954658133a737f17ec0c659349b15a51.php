<?php $__env->startSection('contenido1'); ?>


<div class="container" style="margin: 50px;">
    <form action=" <?php echo e(route('deptos.store')); ?> " method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Nombre:</label>
            <div class="col-8">
                <input type="text" value="<?php echo e(old('nombre')); ?>" class="form-control" name="nombre" id="" placeholder="Ingresar Nombre">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Nombre corto:</label>
            <div class="col-8">
                <input type="text" value="<?php echo e(old('nombrecorto')); ?>" class="form-control" name="nombrecorto" id=""
                    placeholder="Ingrese el Nombre del Departamento">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Descripción:</label>
            <div class="col-8">
                <input type="text" value="<?php echo e(old('descripcion')); ?>" class="form-control" name="descripcion" id=""
                    placeholder="Ingrese una descripción">
            </div>
        </div>

      
        <div class="mb-3 row">
            <div class="offset-sm-4 col-sm-8">
                <button type="submit" class="btn btn-primary">Action</button>
            </div>
        </div>
        
        <ul>
            <?php $__currentLoopData = $errors->All(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </ul>

    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/deptos/formulario.blade.php ENDPATH**/ ?>