<?php $__env->startSection('contenido1'); ?>
    <h1 class="display-3">CATALOGO DE ALUMNOS</h1>
    <hr>

    <div class="tools">
        <div class="button_new">
            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('alumnos.create')); ?>" role="button">Nuevo
                Alumno</a>
        </div>

        <div class="search">
            <form action=" <?php echo e(route('alumnos.index')); ?> " method="get">
                <input type="text" id="txtapellido" name="txtapellido">
                <input type="submit" value="Buscar">
            </form>
        </div>
    </div>

    <hr>

    <h6 class="display-6"><?php echo e(session('mensaje' )); ?></h6>

    <div class="table-responsive">
        <table id="table"
            class="table table-striped 
        table-hover	
        table-borderless
        table-primary
        align-middle">
            <thead class="table-light">
                <caption>Listado de Alumno</caption>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Accion</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-primary">
                        <td>
                            <img src="<?php echo e($alumno->foto); ?>" style="width: 50px; height: 50px;" alt="">
                        </td>
                        <td><?php echo e($alumno->id); ?></td>
                        <td scope="row"><?php echo e($alumno->nombre); ?></td>
                        <td><?php echo e($alumno->apellidop); ?></td>
                        <td><?php echo e($alumno->apellidom); ?></td>
                        <td class="accion-btn">
                            <a class="btn btn-primary" href="<?php echo e(route('alumnos.show', ['alumno' => $alumno->id])); ?>">Ver</a>

                            <form method="POST" action="<?php echo e(route('alumnos.destroy', ['alumno' => $alumno->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input class="btn btn-danger " type="submit" value="Eliminar">
                            </form>

                            <a name="" id="" class="btn btn-secondary" role="button"
                                href="<?php echo e(route('alumnos.edit', ['alumno' => $alumno->id])); ?>">Editar</a>       
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <!-- Hoy -->
            </tfoot>
        </table>
    </div>

    <div class="row justify-content-lg-start">
        <div class="col-auto">
            <?php echo e($alumnos->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/alumnos/index.blade.php ENDPATH**/ ?>