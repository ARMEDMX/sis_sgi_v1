<?php $__env->startSection('contenido1'); ?>


<div class="container" style="margin: 50px;">
    <form action=" <?php echo e(route('alumnos.store')); ?> " method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Nombre:</label>
            <div class="col-8">
                <input type="text" class="form-control" name="nombre" id="" placeholder="Nombre">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Apellido Paterno:</label>
            <div class="col-8">
                <input type="text" class="form-control" name="apellidop" id=""
                    placeholder="Apellido Paterno">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Apellido Materno:</label>
            <div class="col-8">
                <input type="text" class="form-control" name="apellidom" id=""
                    placeholder="Apellido Materno">
            </div>
        </div>

        <div class="mb-3 row">
            <div class="offset-sm-4 col-sm-8">
                <button type="submit" class="btn btn-primary">Action</button>
            </div>
        </div>

    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/alumnos/formulario.blade.php ENDPATH**/ ?>