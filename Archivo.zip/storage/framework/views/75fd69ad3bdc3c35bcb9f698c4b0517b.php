<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DEL PERSONAL: </h1>
<hr>
<ul>
    <li><strong>ID:</strong> <?php echo e($personal->id); ?></li>
    <li><strong>RFC:</strong> <?php echo e($personal->RFC); ?></li>
    <li><strong>Nombres:</strong> <?php echo e($personal->Nombres); ?></li>
    <li><strong>Apellido Paterno:</strong> <?php echo e($personal->apellidoP); ?></li>
    <li><strong>Apellido Materno:</strong> <?php echo e($personal->apellidoM); ?></li>
    <li><strong>Licenciatura:</strong> <?php echo e($personal->licenciatura); ?></li>
    <li><strong>Fecha de titulación (Licenciatura):</strong> <?php echo e($personal->licPasTit); ?></li>
    <li><strong>Especialización:</strong> <?php echo e($personal->especializacion); ?></li>
    <li><strong>Fecha de titulación (Especialización):</strong> <?php echo e($personal->espPasTit); ?></li>
    <li><strong>Maestría:</strong> <?php echo e($personal->maestria); ?></li>
    <li><strong>Fecha de titulación (Maestría):</strong> <?php echo e($personal->maePasTit); ?></li>
    <li><strong>Doctorado:</strong> <?php echo e($personal->doctorado); ?></li>
    <li><strong>Fecha de titulación (Doctorado):</strong> <?php echo e($personal->docPasTit); ?></li>
    <li><strong>Departamento:</strong> <?php echo e($personal->deptos->nombre); ?></li>
    <li><strong>Fecha de ingreso (Separación):</strong> <?php echo e($personal->fechaIngSep); ?></li>
    <li><strong>Fecha de ingreso (Institución):</strong> <?php echo e($personal->fechaIngIns); ?></li>
    <li><strong>Puesto:</strong> <?php echo e($personal->puestos->nombre); ?></li>
    <li><strong>Creado en:</strong> <?php echo e($personal->created_at); ?></li>
    <li><strong>Actualizado en:</strong> <?php echo e($personal->updated_at); ?></li>
</ul>
<hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/personals/show.blade.php ENDPATH**/ ?>