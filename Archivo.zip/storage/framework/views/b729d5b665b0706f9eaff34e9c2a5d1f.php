<div class="mb-3 row">
    <label for="<?php echo e($nombre); ?>" class="col-4 col-form-label"><?php echo e($nombre); ?>:</label>
    
    <div class="col-8">
        <input type="file" class="form-control" name="<?php echo e($campo); ?>" value="<?php echo e(old($campo, $valorcampo)); ?>" id="<?php echo e($seleccionArchivos); ?>" placeholder="<?php echo e($holder); ?>">
        <img id="imagenPrevisualizacion" src="<?php echo e($foto); ?>" style="height: 50px; width: 50px;">


        <div class="error">
            <?php $__errorArgs = [$campo];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: brown;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

       
       
        

    </div>

    
</div>

<script>
    const $seleccionArchivos = document.querySelector("#seleccionArchivos"),
  $imagenPrevisualizacion = document.querySelector("#imagenPrevisualizacion");
 
// Escuchar cuando cambie
$seleccionArchivos.addEventListener("change", () => {
  // Los archivos seleccionados, pueden ser muchos o uno
  const archivos = $seleccionArchivos.files;
  // Si no hay archivos salimos de la función y quitamos la imagen
  if (!archivos || !archivos.length) {
    $imagenPrevisualizacion.src = "";
    return;
  }
  // Ahora tomamos el primer archivo, el cual vamos a previsualizar
  const primerArchivo = archivos[0];
  // Lo convertimos a un objeto de tipo objectURL
  const objectURL = URL.createObjectURL(primerArchivo);
  // Y a la fuente de la imagen le ponemos el objectURL
  $imagenPrevisualizacion.src = objectURL;
});
</script>
<?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/components/input-foto.blade.php ENDPATH**/ ?>