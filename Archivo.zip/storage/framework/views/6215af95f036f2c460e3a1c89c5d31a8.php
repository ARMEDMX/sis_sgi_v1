<?php $__env->startSection('contenido1'); ?>
<div class="card w-50 mx-auto mt-4">
    <div class="card-body text-center">
        <div class="d-flex justify-content-center">
            <img src="<?php echo e(asset($alumno->foto)); ?>" alt="Foto del Alumno" class="card-img-top img-fluid rounded" style="max-height: 300px; max-width: 300px;">
        </div>
        <h5 class="card-title mt-3"><?php echo e($alumno->nombre); ?> <?php echo e($alumno->apellidop); ?> <?php echo e($alumno->apellidom); ?></h5>
        <ul class="list-group">
            <li class="list-group-item">ID: <?php echo e($alumno->id); ?></li>
            <li class="list-group-item">Fecha de Creación: <?php echo e($alumno->created_at); ?></li>
            <li class="list-group-item">Fecha de Actualización: <?php echo e($alumno->updated_at); ?></li>
        </ul>
    </div>
    <div class="card-footer text-center">
        <a href="<?php echo e(route('alumnos.destroy', ['alumno' => $alumno->id])); ?>" class="btn btn-danger">Eliminar Alumno</a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/alumnos/show.blade.php ENDPATH**/ ?>