<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DEL PUESTO: </h1>
<hr>
<ul>
    <li><?php echo e($puesto->id); ?></li>
    <li><?php echo e($puesto->nombre); ?></li>
    <li><?php echo e($puesto->tipo); ?></li>
    <li><?php echo e($puesto->created_at); ?></li>
    <li><?php echo e($puesto->updated_at); ?></li>
</ul>
<hr>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/puestos/show.blade.php ENDPATH**/ ?>