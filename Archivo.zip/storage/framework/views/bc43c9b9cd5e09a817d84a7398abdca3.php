<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DE LOS PERIODOS: </h1>
<hr>
<ul>
    <li><?php echo e($periodo->id); ?></li>
    <li><?php echo e($periodo->periodo); ?></li>
    <li><?php echo e($periodo->descCorta); ?></li>
    <li><?php echo e($periodo->fechaIni); ?></li>
    <li><?php echo e($periodo->fechaFin); ?></li>
    <li><?php echo e($periodo->created_at); ?></li>
    <li><?php echo e($periodo->updated_at); ?></li>
</ul>
<hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/periodos/show.blade.php ENDPATH**/ ?>