@extends("plantillas/plantilla1")

@section("contenido1")

    <h1 class="display-1 bg-danger">En construcción...</h1>
    <h2 class="display-3 bg-danger">CRUD: PLAZAS </h2>


@endsection