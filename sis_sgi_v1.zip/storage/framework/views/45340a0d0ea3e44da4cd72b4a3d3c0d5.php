<?php $__env->startSection("contenido1"); ?>

    <h1 class="display-1 bg-danger">En construcción...</h1>
    <h2 class="display-3 bg-danger">CRUD: ALUMNOS </h2>
    
    <hr>
    
    <p>Personas</p>
    <a href=" <?php echo e(route('modal')); ?> " style="color: black;">Aqui esta la modal</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantillas/plantilla1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/catalogo/alumnos.blade.php ENDPATH**/ ?>