<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/index.css?1.0')); ?>" media="all" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido1'); ?>
    <h1 class="display-3">CATALOGO DEL PERSONAL DE PLAZA: </h1>
    <hr>

    <div class="tools">
        <div class="button_new">
            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('personalplazas.create')); ?>" role="button">
                Nuevo Personal de Plaza</a>
        </div>

        <div class="search">
            <form action="  " method="get">
                <input type="text" id="txtrfc" name="txtrfc">
                <input type="submit" value="Buscar">
            </form>
        </div>
        
    </div>

    <hr>

    <div class="table-responsive">
        <?php if($personalplazas->isEmpty()): ?>
            <p>No se encontraron datos existentes.</p>
        <?php else: ?>
            <table id="table"
                class="table table-striped
            table-hover	
            table-borderless
            table-primary
            align-middle">
                <thead class="table-light">
                    <caption>Listado de Personal</caption>
                    <tr>
                        <th>ID</th>
                        <th>Tipo de Nombramiento</th>
                        <th>RFC</th>
                        <th>Plazas</th>
                    
                        <th>Accion</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $personalplazas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalplaza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            <td><?php echo e($personalplaza->id); ?></td>
                            <td><?php echo e($personalplaza->tipoNombramiento); ?></td>
                            <td><?php echo e($personalplaza->personal->RFC); ?></td>
                            <td><?php echo e($personalplaza->plazas->nombrePlaza); ?></td>
                            
                            
                            
                            <td class="accion-btn">

                                
                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('personalplazas.show', ['personalplaza' => $personalplaza->id])); ?>">Ver</a>
                                

                                
                                    <form method="POST" action="<?php echo e(route('personalplazas.destroy', ['personalplaza' => $personalplaza->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input class="btn btn-danger " type="submit" value="Eliminar">
                                    </form>
                                    
                                

                                
                                    <a name="" id="" class="btn btn-secondary" role="button"
                                        href="<?php echo e(route('personalplazas.edit', ['personalplaza' => $personalplaza->id])); ?>">Editar</a>
                                

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <!-- Hoy -->
                </tfoot>
            </table>
    </div>

    <div class="row justify-content-lg-start">
        <div class="col-auto">
            <?php echo e($personalplazas->links()); ?>

        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/personalplazas/index.blade.php ENDPATH**/ ?>