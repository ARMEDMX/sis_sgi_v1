<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/index.css?1.0')); ?>" media="all" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido1'); ?>
    <div class="title">
        <h1 class="display-3">CATALOGO DE LUGARES: </h1>
    </div>
    
    <hr>

    <div class="tools">
        <div class="button_new">
            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('lugares.create')); ?>" role="button">Nuevo
                Lugar</a>
        </div>

        <div class="search">
            <form action=" <?php echo e(route('lugares.index')); ?> " method="get">
                <input type="text" id="txtnombrelugar" name="txtnombrelugar">
                <input type="submit" value="Buscar">
            </form>
        </div>
    </div>

    <hr>


    <div class="table-responsive">
        <?php if($Lugar->isEmpty()): ?>
            <p>No se encontraron datos existentes.</p>
        <?php else: ?>
        <table id="table"
            class="table table-striped
            table-hover	
            table-borderless
            table-primary
            align-middle">
            <thead class="table-light">
                <caption>Listado de Departamentos</caption>
                <tr>
                    <th>ID</th>
                    <th>Nombre Lugar</th>
                    <th>Descripcion</th>
                    <th>Edificio</th>
                    <th>Accion</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php $__currentLoopData = $Lugar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Lugares): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-primary">
                        <td><?php echo e($Lugares->id); ?></td>
                        <td><?php echo e($Lugares->nombreLugar); ?></td>
                        <td><?php echo e($Lugares->descripcion); ?></td>
                        <td><?php echo e($Lugares->edificio); ?></td>
                        <td>
                            
                                <a class="btn btn-primary"
                                    href="<?php echo e(route('lugares.show', ['Lugares' => $Lugares->id])); ?>">Ver</a>
                            

                            <form method="POST" action="<?php echo e(route('lugares.destroy', ['Lugares' => $Lugares->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input class="btn btn-danger " type="submit" value="Eliminar">
                            </form>

                            
                                <a name="" id="" class="btn btn-secondary" role="button"
                                    href="<?php echo e(route('lugares.edit', ['Lugares' => $Lugares->id])); ?>">Editar</a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <!-- Hoy -->
            </tfoot>
        </table>
    </div>


    <div class="row justify-content-lg-start">
        <div class="col-auto">
            <?php echo e($Lugar->links()); ?>

        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/lugares/index.blade.php ENDPATH**/ ?>