<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DE CARRERAS: </h1>
<hr>
<ul>
    <li>ID: <?php echo e($carrera->id); ?></li>
    <li>Nombre: <?php echo e($carrera->nombre); ?></li>
    <li>Nombre Corto: <?php echo e($carrera->nombrecorto); ?></li>
    <li>Departamento: <?php echo e($carrera->depto->nombre); ?></li>
    <li><?php echo e($carrera->created_at); ?></li>
    <li><?php echo e($carrera->updated_at); ?></li>
</ul>
<hr>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/carreras/show.blade.php ENDPATH**/ ?>