<?php $__env->startSection("contenido1"); ?>

    <h1 class="display-1 bg-danger">En construcción...</h1>
    <h2 class="display-3 bg-danger">CRUD: LUGARES </h2>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantillas/plantilla1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/catalogo/lugares.blade.php ENDPATH**/ ?>