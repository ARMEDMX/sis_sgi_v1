<select name="nivel">
    <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($nivel); ?>"><?php echo e($nivel); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/components/select-2.blade.php ENDPATH**/ ?>