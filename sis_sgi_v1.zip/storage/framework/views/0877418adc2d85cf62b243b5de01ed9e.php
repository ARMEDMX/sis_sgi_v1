<?php $__env->startSection("contenido1"); ?>

    <form action=" <?php echo e(route('respuesta')); ?> " method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="" class="form-label">Nombre: </label>
          <input type="text"
            class="form-control" name="nombre" id="" value="" aria-describedby="helpId" placeholder="Nombre">
        </div>

        <div class="mb-3">
          <label for="" class="form-label">Apellido Paterno: </label>
          <input type="text"
            class="form-control" name="apellidop" id="" value="" aria-describedby="helpId" placeholder="Apellido Paterno">
        </div>


                
        <button type="submit" class="btn btn-primary">Enviar Datos</button>
    </form>
    
  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("plantillas/plantilla1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/frm/frm1.blade.php ENDPATH**/ ?>