<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/index.css?1.0')); ?>" media="all" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <title>Document</title>
</head>

<body>

    <!-- NavBar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info"">
        <div class=" container-fluid">
        <a class="navbar-brand" href="#">SGI</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Horarios</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Carga de Archivos</a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Catalogos
                    </a>
                    <ul class="dropdown-menu bg-primary " aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="<?php echo e(route ('alumnos.index')); ?>">Alumnos</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('deptos.index')); ?>">Departamentos</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('reticulas.index')); ?>">Reticulas</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('materias.index')); ?>">Materias</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('periodos.index')); ?>">Periodos</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('puestos.index')); ?>">Puestos</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('personal.index')); ?>">Personal</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('personalplazas.index')); ?>">Personal Plazas</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('lugares.index')); ?>">Lugares</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('plazas.index')); ?>">Plazas</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route ('carreras.index')); ?>">Carreras</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="/viewmodal">Something else here</a></li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Ayuda</a>
                </li>



            </ul>

            <!-- <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form> -->

            <!-- Boton LOGOUT -->
            <?php if(auth()->guard()->check()): ?>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    <?php echo e(Auth::user()->email); ?>

                </button>
                <ul class="dropdown-menu dropdown-menu bg-info">
                    <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Perfil</a></li>
                    <li>
                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <a class="dropdown-item" href=""
                                onclick="event.preventDefault(); this.closest('form').submit();">Cerrar Sesion</a>
                        </form>
                    </li>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
            <div class="bg-primary" style="padding: 5px; border-radius: 10px 0px 10px 0px;">
                <a href="/login" style="color:black; text-decoration: none;">Iniciar Sesion</a>
            </div>
            <?php endif; ?>

        </div>
        </div>
    </nav>





    <div class="row">
        <div class="col">
            <?php echo $__env->yieldContent("contenido1"); ?>
        </div>
    </div>




</body>

</html><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/plantillas/plantilla1.blade.php ENDPATH**/ ?>