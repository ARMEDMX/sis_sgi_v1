<?php $__env->startSection('contenido1'); ?>
<div class="container" style="margin: 50px;">
    
        <form action="<?php echo e(route('deptos.update', ['deptos' => $deptos->id] )); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> <!-- Usamos el método PUT para la actualización -->
        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Nombre:</label>
            <div class="col-8">
                <input type="text" value="<?php echo e(old('nombre', $deptos->nombre)); ?>" class="form-control" name="nombre" id="">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Nombre corto:</label>
            <div class="col-8">
                <input type="text" value="<?php echo e($deptos->nombrecorto); ?>" class="form-control" name="nombrecorto" id="">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputName" class="col-4 col-form-label">Descripción:</label>
            <div class="col-8">
                <input type="text" value="<?php echo e($deptos->descripcion); ?>" class="form-control" name="descripcion" id="">
            </div>
        </div>

     

        <div class="mb-3 row">
            <div class="offset-sm-4 col-sm-8">
                <button type="submit" class="btn btn-primary">Actualizar</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/deptos/edit.blade.php ENDPATH**/ ?>