<?php $__env->startSection('contenido1'); ?>
    
<h1 class="display-5">DATOS DE PERSONAL PLAZAS: </h1>
<hr>
<ul>
    <li><strong>ID:</strong> <?php echo e($personalplaza->id); ?></li>
    <li><strong>Tipo de Nombramiento:</strong> <?php echo e($personalplaza->tipoNombramiento); ?></li>
    <li><strong>Nombres:</strong> <?php echo e($personalplaza->personal->RFC); ?></li>
    <li><strong>Apellido Paterno:</strong> <?php echo e($personalplaza->plazas->nombrePlaza); ?></li>

    <li><strong>Creado en:</strong> <?php echo e($personalplaza->created_at); ?></li>
    <li><strong>Actualizado en:</strong> <?php echo e($personalplaza->updated_at); ?></li>
</ul>
<hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/frontdevmx/directorio_web/sis_sgi_v1/resources/views/personalplazas/show.blade.php ENDPATH**/ ?>