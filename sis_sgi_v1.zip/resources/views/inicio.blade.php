@extends("plantillas/plantilla1")

@section("contenido1")

    <h1 class="display-1"> BIENVENIDOS</h1>

@endsection